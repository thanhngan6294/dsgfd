#include "dbeditmainwindow.h"
#include <QApplication>
#include <QDebug>
#include <QStringList>
#include <QRegularExpression>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QString fileName;

    if (argc >= 2)
        fileName = argv[1];
    else
        fileName = "";
    DbEditMainWindow w;
    QString line(" SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] \"\"  NODE1");
    QStringList lineItems2 =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\\+"),QString::SkipEmptyParts);//|([A-Za-z]\w+)

    qDebug()<<lineItems2.size() << lineItems2;

    w.show();

    return a.exec();
}
